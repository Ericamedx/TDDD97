Hello! 

To start, initialize the database by cd to Twidder map: sqlite3 database.db < schema.sql

After that use python views.py.

Then everything should be working. 